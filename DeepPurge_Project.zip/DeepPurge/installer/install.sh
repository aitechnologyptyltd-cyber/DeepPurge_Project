#!/bin/bash
# ============================================================================
# DeepPurge Installer - runs under Git Bash on Windows
# Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
#
# This script:
#   1. Checks for prerequisites (.NET 8 SDK, Git)
#   2. Builds DeepPurge from source (Release, x64)
#   3. Installs it to Program Files
#   4. Fetches ClamAV (open-source antivirus engine) for the Threat Scan Gate
#   5. Creates a Start Menu shortcut
#   6. Registers scheduled tasks (quarantine purge + threat-DB updates)
#
# Run this from the root of the DeepPurge source tree:
#   bash installer/install.sh
# ============================================================================

set -e

INSTALL_DIR="/c/Program Files/DeepPurge"
SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "============================================================"
echo " DeepPurge Installer"
echo " Sole Developer & Architect: Francois Nel"
echo "============================================================"
echo "Source root: $SOURCE_ROOT"
echo

# ---------------------------------------------------------------------------
# Step 1: Check prerequisites
# ---------------------------------------------------------------------------
echo "[1/7] Checking prerequisites..."

if ! command -v dotnet &> /dev/null; then
    echo "ERROR: .NET SDK not found on PATH."
    echo
    echo "DeepPurge targets .NET 8. Install it first:"
    echo "  1. Download the .NET 8 SDK installer from:"
    echo "     https://dotnet.microsoft.com/download/dotnet/8.0"
    echo "  2. Run the installer, then restart Git Bash and re-run this script."
    echo
    echo "  (Alternative if you have winget available, from an elevated"
    echo "   PowerShell/CMD, NOT Git Bash: winget install Microsoft.DotNet.SDK.8)"
    exit 1
fi

DOTNET_VERSION=$(dotnet --version)
echo "    Found .NET SDK: $DOTNET_VERSION"

if ! command -v git &> /dev/null; then
    echo "WARNING: git not found on PATH. Not required if you already have the"
    echo "         source locally (which you do, since this script is running),"
    echo "         but you won't be able to pull future updates via git."
fi

if ! command -v curl.exe &> /dev/null && ! command -v curl &> /dev/null; then
    echo "WARNING: curl not found. ClamAV auto-download (step 4) will be skipped;"
    echo "         Windows Defender will still work as the second scan engine."
fi

# ---------------------------------------------------------------------------
# Step 2: Restore & build (Release, x64)
# ---------------------------------------------------------------------------
echo
echo "[2/7] Restoring NuGet packages..."
dotnet restore "$SOURCE_ROOT/DeepPurge.sln"

echo
echo "[3/7] Building DeepPurge (Release, x64)..."
dotnet publish "$SOURCE_ROOT/src/DeepPurge.CLI/DeepPurge.CLI.csproj" \
    -c Release -r win-x64 --self-contained true \
    -p:PublishSingleFile=true \
    -o "$SOURCE_ROOT/publish"

echo "    Build output: $SOURCE_ROOT/publish"

# ---------------------------------------------------------------------------
# Step 3: Install to Program Files
# ---------------------------------------------------------------------------
echo
echo "[4/7] Installing to \"$INSTALL_DIR\"..."
mkdir -p "$INSTALL_DIR"
cp -f "$SOURCE_ROOT/publish/DeepPurge.exe" "$INSTALL_DIR/"
mkdir -p "$INSTALL_DIR/Database"
cp -f "$SOURCE_ROOT/src/DeepPurge.Core/Database/Schema.sql" "$INSTALL_DIR/Database/"

# ---------------------------------------------------------------------------
# Step 4: Fetch ClamAV for Windows (open-source, GPL, redistributable).
# This is the only AV engine DeepPurge bundles. Windows Defender is used as
# the second engine via its own already-installed MpCmdRun.exe, so nothing
# else needs downloading for that one - see docs for why DeepPurge does not
# bundle proprietary commercial AV engines.
# ---------------------------------------------------------------------------
echo
echo "[5/7] Setting up ClamAV (open-source antivirus engine)..."
CLAMAV_DIR="$INSTALL_DIR/ClamAV"
mkdir -p "$CLAMAV_DIR"

if [ -f "$CLAMAV_DIR/clamscan.exe" ]; then
    echo "    ClamAV already present at $CLAMAV_DIR - skipping download."
else
    CLAMAV_ZIP="$SOURCE_ROOT/clamav-win-x64.zip"
    echo "    Downloading ClamAV for Windows (x64) release..."
    echo "    (Official source: https://www.clamav.net/downloads)"
    # NOTE: the exact filename/version changes with each ClamAV release.
    # If this URL 404s, check https://www.clamav.net/downloads for the
    # current "win-x64" zip and update CLAMAV_URL below.
    CLAMAV_URL="https://www.clamav.net/downloads/production/clamav-1.4.1.win.x64.zip"
    if curl.exe -L -f -o "$CLAMAV_ZIP" "$CLAMAV_URL" 2>/dev/null || curl -L -f -o "$CLAMAV_ZIP" "$CLAMAV_URL" 2>/dev/null; then
        powershell.exe -NoProfile -Command "Expand-Archive -Path '$CLAMAV_ZIP' -DestinationPath '$CLAMAV_DIR' -Force"
        # The zip extracts into a version-named subfolder; flatten it.
        INNER=$(find "$CLAMAV_DIR" -maxdepth 1 -type d -name "clamav-*" | head -n1)
        if [ -n "$INNER" ]; then
            cp -rf "$INNER"/* "$CLAMAV_DIR/"
            rm -rf "$INNER"
        fi
        rm -f "$CLAMAV_ZIP"
        echo "    ClamAV installed to $CLAMAV_DIR"
    else
        echo "    WARNING: ClamAV download failed or URL is stale. DeepPurge still"
        echo "    works - it falls back to Windows Defender alone for threat scanning."
        echo "    To add ClamAV manually: download the win-x64 zip from"
        echo "    https://www.clamav.net/downloads and extract its contents into:"
        echo "      $CLAMAV_DIR"
    fi
fi

if [ -f "$CLAMAV_DIR/freshclam.exe" ]; then
    echo "    Fetching initial virus signature database (can take a few minutes)..."
    mkdir -p "$CLAMAV_DIR/database"
    "$CLAMAV_DIR/freshclam.exe" --datadir="$CLAMAV_DIR/database" || \
        echo "    WARNING: signature download failed - run 'DeepPurge.exe update-threat-db' later."
fi

# ---------------------------------------------------------------------------
# Step 5: Start Menu shortcut
# ---------------------------------------------------------------------------
echo
echo "[6/7] Creating Start Menu shortcut..."
STARTMENU="/c/Users/$(whoami)/AppData/Roaming/Microsoft/Windows/Start Menu/Programs"
powershell.exe -NoProfile -Command "
\$ws = New-Object -ComObject WScript.Shell;
\$sc = \$ws.CreateShortcut('$STARTMENU\\DeepPurge.lnk');
\$sc.TargetPath = 'C:\\Program Files\\DeepPurge\\DeepPurge.exe';
\$sc.WorkingDirectory = 'C:\\Program Files\\DeepPurge';
\$sc.Description = 'DeepPurge - Deep System Uninstaller (Francois Nel)';
\$sc.Save();
" || echo "    (Shortcut creation skipped - run manually if this failed.)"

# ---------------------------------------------------------------------------
# Step 6: Register scheduled tasks
# ---------------------------------------------------------------------------
echo
echo "[7/7] Registering scheduled tasks..."
schtasks.exe /Create /TN "DeepPurge Quarantine Cleanup" \
    /TR "\"C:\\Program Files\\DeepPurge\\DeepPurge.exe\" purge-expired" \
    /SC DAILY /ST 03:30 /RL HIGHEST /F || \
    echo "    (Quarantine-cleanup task creation failed - try running this script as Administrator.)"

schtasks.exe /Create /TN "DeepPurge Threat DB Update" \
    /TR "\"C:\\Program Files\\DeepPurge\\DeepPurge.exe\" update-threat-db" \
    /SC DAILY /ST 04:00 /RL HIGHEST /F || \
    echo "    (Threat-DB-update task creation failed - try running this script as Administrator.)"

echo
echo "============================================================"
echo " Installation complete."
echo " Run from any terminal:  DeepPurge.exe   (add to PATH manually if desired)"
echo " Or use the Start Menu shortcut: DeepPurge"
echo
echo " IMPORTANT: Right-click and 'Run as Administrator' for full-depth"
echo " scans - DeepPurge needs elevation to see every hidden file and"
echo " every user's registry hive."
echo "============================================================"
