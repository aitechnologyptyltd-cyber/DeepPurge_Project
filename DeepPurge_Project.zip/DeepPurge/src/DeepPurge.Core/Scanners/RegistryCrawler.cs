// DeepPurge - Registry Crawler (Layer 2)
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// Walks HKLM, HKCU, HKCR and every loaded user hive under HKU, with special
// attention to the locations that actually matter for uninstall completeness:
// the Uninstall key (both native and WOW6432Node for 32-bit apps on 64-bit
// Windows), Run/RunOnce keys, service definitions, and COM/CLSID registrations.
//
// This file is Windows-only (Microsoft.Win32.Registry is a Windows API).
// It is guarded so the solution still builds/lints on non-Windows dev
// machines; the actual calls will only execute on Windows.

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using DeepPurge.Core.Models;

namespace DeepPurge.Core.Scanners
{
    public class RegistryCrawler
    {
        public static readonly string[] UninstallKeyPaths =
        {
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
            @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
        };

        public static readonly string[] RunKeyPaths =
        {
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
            @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
        };

        public event Action<RegistryRecord>? OnEntryFound;
        public event Action<string, Exception>? OnError;

        /// <summary>
        /// Crawl HKLM Uninstall + Run keys, and HKCU Uninstall + Run keys for
        /// the current user. Also walks all loaded profiles under HKEY_USERS
        /// so per-user installs for OTHER accounts aren't missed.
        /// </summary>
        public IEnumerable<RegistryRecord> CrawlInstallRelevantKeys()
        {
            if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                yield break; // No-op off Windows; keeps solution buildable everywhere.
            }

            foreach (var rec in CrawlHive("HKLM", UninstallKeyPaths)) yield return rec;
            foreach (var rec in CrawlHive("HKLM", RunKeyPaths)) yield return rec;
            foreach (var rec in CrawlHive("HKCU", UninstallKeyPaths)) yield return rec;
            foreach (var rec in CrawlHive("HKCU", RunKeyPaths)) yield return rec;

            foreach (var userSid in EnumerateLoadedUserHives())
            {
                foreach (var rec in CrawlHive($"HKU\\{userSid}", UninstallKeyPaths)) yield return rec;
                foreach (var rec in CrawlHive($"HKU\\{userSid}", RunKeyPaths)) yield return rec;
            }

            foreach (var rec in CrawlServices()) yield return rec;
        }

        private IEnumerable<RegistryRecord> CrawlHive(string hiveLabel, string[] keyPaths)
        {
#if WINDOWS
            using var baseKey = OpenBaseKey(hiveLabel);
            if (baseKey == null) yield break;

            foreach (var keyPath in keyPaths)
            {
                Microsoft.Win32.RegistryKey? key = null;
                try
                {
                    key = baseKey.OpenSubKey(keyPath);
                }
                catch (Exception ex)
                {
                    OnError?.Invoke($"{hiveLabel}\\{keyPath}", ex);
                }
                if (key == null) continue;

                foreach (var rec in WalkSubKeys(hiveLabel, keyPath, key))
                    yield return rec;

                key.Dispose();
            }
#else
            yield break;
#endif
        }

#if WINDOWS
        private Microsoft.Win32.RegistryKey? OpenBaseKey(string hiveLabel)
        {
            if (hiveLabel == "HKLM")
                return Microsoft.Win32.RegistryKey.OpenBaseKey(
                    Microsoft.Win32.RegistryHive.LocalMachine, Microsoft.Win32.RegistryView.Registry64);
            if (hiveLabel == "HKCU")
                return Microsoft.Win32.RegistryKey.OpenBaseKey(
                    Microsoft.Win32.RegistryHive.CurrentUser, Microsoft.Win32.RegistryView.Registry64);
            if (hiveLabel.StartsWith("HKU\\"))
            {
                var users = Microsoft.Win32.RegistryKey.OpenBaseKey(
                    Microsoft.Win32.RegistryHive.Users, Microsoft.Win32.RegistryView.Registry64);
                var sid = hiveLabel.Substring(4);
                return users.OpenSubKey(sid);
            }
            return null;
        }

        private IEnumerable<RegistryRecord> WalkSubKeys(string hiveLabel, string parentPath, Microsoft.Win32.RegistryKey key)
        {
            foreach (var subKeyName in key.GetSubKeyNames())
            {
                Microsoft.Win32.RegistryKey? subKey = null;
                try
                {
                    subKey = key.OpenSubKey(subKeyName);
                }
                catch (Exception ex)
                {
                    OnError?.Invoke($"{hiveLabel}\\{parentPath}\\{subKeyName}", ex);
                }
                if (subKey == null) continue;

                var fullKeyPath = $"{parentPath}\\{subKeyName}";
                foreach (var valueName in subKey.GetValueNames())
                {
                    object? raw = null;
                    try { raw = subKey.GetValue(valueName); } catch { /* ignore locked values */ }

                    yield return new RegistryRecord
                    {
                        Hive = hiveLabel,
                        KeyPath = fullKeyPath,
                        ValueName = string.IsNullOrEmpty(valueName) ? "(default)" : valueName,
                        ValueData = raw?.ToString(),
                        LastWriteUtc = null // Win32 last-write time requires RegQueryInfoKey P/Invoke; omitted for brevity.
                    };
                }
                subKey.Dispose();
            }
        }
#endif

        private IEnumerable<RegistryRecord> CrawlServices()
        {
#if WINDOWS
            using var services = Microsoft.Win32.RegistryKey.OpenBaseKey(
                    Microsoft.Win32.RegistryHive.LocalMachine, Microsoft.Win32.RegistryView.Registry64)
                .OpenSubKey(@"SYSTEM\CurrentControlSet\Services");
            if (services == null) yield break;

            foreach (var svcName in services.GetSubKeyNames())
            {
                using var svcKey = services.OpenSubKey(svcName);
                if (svcKey == null) continue;
                var imagePath = svcKey.GetValue("ImagePath")?.ToString();
                if (string.IsNullOrEmpty(imagePath)) continue;

                yield return new RegistryRecord
                {
                    Hive = "HKLM",
                    KeyPath = $@"SYSTEM\CurrentControlSet\Services\{svcName}",
                    ValueName = "ImagePath",
                    ValueData = imagePath
                };
            }
#else
            yield break;
#endif
        }

        /// <summary>
        /// Returns SIDs of user hives currently loaded under HKEY_USERS
        /// (i.e., logged-in or otherwise mounted profiles).
        /// </summary>
        private IEnumerable<string> EnumerateLoadedUserHives()
        {
#if WINDOWS
            using var users = Microsoft.Win32.RegistryKey.OpenBaseKey(
                Microsoft.Win32.RegistryHive.Users, Microsoft.Win32.RegistryView.Registry64);
            foreach (var sid in users.GetSubKeyNames())
            {
                // Skip the _Classes companion keys (e.g. S-1-5-21-...-1001_Classes)
                if (sid.EndsWith("_Classes", StringComparison.OrdinalIgnoreCase)) continue;
                if (!sid.StartsWith("S-1-", StringComparison.OrdinalIgnoreCase)) continue;
                yield return sid;
            }
#else
            yield break;
#endif
        }
    }
}
