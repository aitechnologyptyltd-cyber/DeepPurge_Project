// DeepPurge - Filesystem Crawler (Layer 1)
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// Recursively walks the filesystem, prioritizing known install zones first,
// then optionally sweeping whole drives. Detects hidden/system files,
// reparse points (to avoid infinite loops through symlinks/junctions), and
// flags files that carry NTFS Alternate Data Streams.
//
// NOTE: Full hidden/system file visibility and ADS enumeration require
// running elevated (Administrator) on Windows. This module degrades
// gracefully (skips what it cannot see) rather than crashing when run
// without elevation - but a "maximum depth" scan should always be run as
// Administrator.

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using DeepPurge.Core.Models;

namespace DeepPurge.Core.Scanners
{
    public class FileSystemCrawler
    {
        public static readonly string[] DefaultPriorityRoots =
        {
            "%ProgramFiles%",
            "%ProgramFiles(x86)%",
            "%ProgramData%",
            "%LocalAppData%",
            "%AppData%",
            "%LocalAppData%\\Temp",
            "%UserProfile%\\AppData\\LocalLow"
        };

        public event Action<string>? OnDirectoryEntered;
        public event Action<FileRecord>? OnFileFound;
        public event Action<string, Exception>? OnError;

        private readonly HashSet<string> _visitedRealPaths = new(StringComparer.OrdinalIgnoreCase);
        public long FilesScanned { get; private set; }
        public long DirectoriesSkippedDueToLoop { get; private set; }

        /// <summary>
        /// Crawl the given priority roots (env-var expanded) plus, if fullDriveSweep
        /// is true, every fixed drive from root. Yields FileRecord for every file found.
        /// </summary>
        public IEnumerable<FileRecord> Crawl(IEnumerable<string> roots, bool fullDriveSweep, bool computeHashes = false)
        {
            foreach (var rawRoot in roots)
            {
                var expanded = Environment.ExpandEnvironmentVariables(rawRoot);
                if (string.IsNullOrWhiteSpace(expanded) || !Directory.Exists(expanded))
                    continue;

                foreach (var record in CrawlDirectory(expanded, computeHashes))
                    yield return record;
            }

            if (fullDriveSweep)
            {
                foreach (var drive in DriveInfo.GetDrives())
                {
                    if (drive.DriveType != DriveType.Fixed || !drive.IsReady) continue;
                    foreach (var record in CrawlDirectory(drive.RootDirectory.FullName, computeHashes))
                        yield return record;
                }
            }
        }

        private IEnumerable<FileRecord> CrawlDirectory(string path, bool computeHashes)
        {
            // Guard against symlink/junction loops: resolve the real path and
            // skip if we've already visited it.
            string realPath;
            try
            {
                realPath = new DirectoryInfo(path).LinkTarget ?? path;
            }
            catch
            {
                realPath = path;
            }

            if (!_visitedRealPaths.Add(realPath))
            {
                DirectoriesSkippedDueToLoop++;
                yield break;
            }

            OnDirectoryEntered?.Invoke(path);

            IEnumerable<string> subDirs = Array.Empty<string>();
            IEnumerable<string> files = Array.Empty<string>();

            try
            {
                // EnumerateFileSystemEntries surfaces hidden/system entries fine as
                // long as the process has sufficient privileges; no special flag
                // needed in modern .NET beyond running elevated.
                subDirs = Directory.EnumerateDirectories(WithLongPathPrefix(path));
            }
            catch (Exception ex)
            {
                OnError?.Invoke(path, ex);
            }

            try
            {
                files = Directory.EnumerateFiles(WithLongPathPrefix(path));
            }
            catch (Exception ex)
            {
                OnError?.Invoke(path, ex);
            }

            foreach (var file in files)
            {
                FileRecord? record = null;
                try
                {
                    record = BuildFileRecord(file, computeHashes);
                    FilesScanned++;
                }
                catch (Exception ex)
                {
                    OnError?.Invoke(file, ex);
                }

                if (record != null)
                {
                    OnFileFound?.Invoke(record);
                    yield return record;
                }
            }

            foreach (var dir in subDirs)
            {
                IEnumerator<FileRecord>? enumerator = null;
                try
                {
                    enumerator = CrawlDirectory(dir, computeHashes).GetEnumerator();
                }
                catch (Exception ex)
                {
                    OnError?.Invoke(dir, ex);
                }

                if (enumerator == null) continue;

                while (true)
                {
                    bool moved;
                    FileRecord? current = null;
                    try
                    {
                        moved = enumerator.MoveNext();
                        if (moved) current = enumerator.Current;
                    }
                    catch (Exception ex)
                    {
                        OnError?.Invoke(dir, ex);
                        break;
                    }

                    if (!moved) break;
                    if (current != null) yield return current;
                }
            }
        }

        private FileRecord BuildFileRecord(string path, bool computeHashes)
        {
            var fi = new FileInfo(path);
            var attrs = fi.Attributes;

            var record = new FileRecord
            {
                FullPath = path,
                SizeBytes = SafeLength(fi),
                CreatedUtc = fi.CreationTimeUtc,
                ModifiedUtc = fi.LastWriteTimeUtc,
                AccessedUtc = fi.LastAccessTimeUtc,
                IsHidden = attrs.HasFlag(FileAttributes.Hidden),
                IsSystem = attrs.HasFlag(FileAttributes.System),
                IsReparsePoint = attrs.HasFlag(FileAttributes.ReparsePoint),
                HasAlternateDataStreams = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) && HasAds(path)
            };

            if (computeHashes)
            {
                record.Sha256 = TryComputeSha256(path);
            }

            return record;
        }

        private static long SafeLength(FileInfo fi)
        {
            try { return fi.Length; } catch { return 0; }
        }

        private static string WithLongPathPrefix(string path)
        {
            // Enables paths beyond MAX_PATH (260 chars) on Windows.
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) &&
                !path.StartsWith(@"\\?\") && path.Length > 240)
            {
                return @"\\?\" + Path.GetFullPath(path);
            }
            return path;
        }

        /// <summary>
        /// Checks for NTFS Alternate Data Streams by attempting to enumerate
        /// them via the Win32 FindFirstStreamW API. Returns false on any
        /// platform/filesystem that doesn't support it, rather than throwing.
        /// </summary>
        private static bool HasAds(string path)
        {
            try
            {
                return NativeMethods.HasAlternateDataStreams(path);
            }
            catch
            {
                return false;
            }
        }

        private static string? TryComputeSha256(string path)
        {
            try
            {
                using var sha = System.Security.Cryptography.SHA256.Create();
                using var stream = File.OpenRead(path);
                var hash = sha.ComputeHash(stream);
                return Convert.ToHexString(hash);
            }
            catch
            {
                return null; // Locked/inaccessible files are skipped, not fatal.
            }
        }
    }

    /// <summary>
    /// Thin P/Invoke wrapper around FindFirstStreamW/FindNextStreamW for ADS detection.
    /// Only meaningful on Windows/NTFS; safe no-op elsewhere.
    /// </summary>
    internal static class NativeMethods
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct WIN32_FIND_STREAM_DATA
        {
            public long StreamSize;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 296)]
            public string cStreamName;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr FindFirstStreamW(string lpFileName, int InfoLevel,
            out WIN32_FIND_STREAM_DATA lpFindStreamData, uint dwFlags);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool FindNextStreamW(IntPtr hFindStream, out WIN32_FIND_STREAM_DATA lpFindStreamData);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool FindClose(IntPtr hFindFile);

        private const int INVALID_HANDLE_VALUE = -1;

        public static bool HasAlternateDataStreams(string path)
        {
            if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) return false;

            IntPtr handle = FindFirstStreamW(path, 0, out var data, 0);
            if (handle.ToInt64() == INVALID_HANDLE_VALUE) return false;

            try
            {
                // The default unnamed data stream (::$DATA) always exists; more
                // than one entry means a real ADS is present.
                int count = 1;
                while (FindNextStreamW(handle, out data))
                {
                    count++;
                    if (count > 1) return true;
                }
                return count > 1;
            }
            finally
            {
                FindClose(handle);
            }
        }
    }
}
