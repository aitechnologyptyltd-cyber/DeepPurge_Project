// DeepPurge - Deep System Uninstaller & Residual Cleaner
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
// Module: Core Data Models
//
// These POCOs represent every entity the engine reasons about: a file on disk,
// a registry value, a running process/service, and the "Program" record that
// ties them all together once the Association Engine has done its job.

using System;
using System.Collections.Generic;

namespace DeepPurge.Core.Models
{
    public enum DiscoveryMethod
    {
        SnapshotDiff,       // Perfect: before/after install snapshot
        UninstallRegistry,  // Found via HKLM/HKCU Uninstall key
        MsiComponentTable,  // Found via Windows Installer database
        FuzzyFilesystem,    // Path/name/timestamp heuristic match
        RunningProcess,     // Discovered via live process/handle inspection
        Manual              // User pointed at it directly
    }

    public enum RiskLevel
    {
        SafeToDelete = 0,
        LikelySafe = 1,
        SharedComponentCaution = 2,
        Unknown = 3,
        DoNotTouch = 4      // e.g. referenced by another installed program's manifest
    }

    public class FileRecord
    {
        public long Id { get; set; }
        public string FullPath { get; set; } = string.Empty;
        public long SizeBytes { get; set; }
        public DateTime CreatedUtc { get; set; }
        public DateTime ModifiedUtc { get; set; }
        public DateTime AccessedUtc { get; set; }
        public string OwnerSid { get; set; } = string.Empty;
        public bool IsHidden { get; set; }
        public bool IsSystem { get; set; }
        public bool IsReparsePoint { get; set; }
        public bool HasAlternateDataStreams { get; set; }
        public string? Sha256 { get; set; }          // null unless hashing enabled (slow)
        public string? PublisherFromSignature { get; set; }
        public long? OwningProgramId { get; set; }
    }

    public class RegistryRecord
    {
        public long Id { get; set; }
        public string Hive { get; set; } = string.Empty;   // HKLM, HKCU, HKCR, HKU\<sid>
        public string KeyPath { get; set; } = string.Empty;
        public string? ValueName { get; set; }
        public string? ValueData { get; set; }
        public DateTime? LastWriteUtc { get; set; }
        public long? OwningProgramId { get; set; }
    }

    public class ServiceOrTaskRecord
    {
        public long Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty; // "Service" | "ScheduledTask" | "RunKey" | "StartupFolder"
        public string? BinaryPath { get; set; }
        public long? OwningProgramId { get; set; }
    }

    public class ProgramRecord
    {
        public long Id { get; set; }
        public string DisplayName { get; set; } = string.Empty;
        public string? Publisher { get; set; }
        public string? DisplayVersion { get; set; }
        public string? InstallLocation { get; set; }
        public string? UninstallString { get; set; }
        public DateTime? InstallDateUtc { get; set; }
        public DiscoveryMethod Discovery { get; set; }
        public double ConfidenceScore { get; set; } // 0.0 - 1.0, from Association Engine
        public List<long> FileIds { get; set; } = new();
        public List<long> RegistryIds { get; set; } = new();
        public List<long> ServiceIds { get; set; } = new();
    }

    public class LeftoverFinding
    {
        public long ProgramId { get; set; }
        public string ProgramName { get; set; } = string.Empty;
        public string ItemType { get; set; } = string.Empty; // "File" | "Folder" | "RegistryKey" | "Service" | "Task"
        public string Path { get; set; } = string.Empty;
        public RiskLevel Risk { get; set; }
        public string RiskReason { get; set; } = string.Empty;
    }

    public class SnapshotManifest
    {
        public string ManifestId { get; set; } = Guid.NewGuid().ToString("N");
        public DateTime TakenAtUtc { get; set; }
        public string Label { get; set; } = string.Empty; // "pre-install" | "post-install"
    }
}
