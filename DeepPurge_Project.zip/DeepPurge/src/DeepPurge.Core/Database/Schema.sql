-- DeepPurge master index schema
-- Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
-- SQLite, WAL mode recommended for concurrent scanner writes.

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Programs (
    Id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    DisplayName         TEXT NOT NULL,
    Publisher           TEXT,
    DisplayVersion      TEXT,
    InstallLocation     TEXT,
    UninstallString     TEXT,
    InstallDateUtc      TEXT,
    DiscoveryMethod     TEXT NOT NULL,
    ConfidenceScore     REAL NOT NULL DEFAULT 0.0,
    CreatedUtc          TEXT NOT NULL DEFAULT (datetime('now')),
    UpdatedUtc          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS Files (
    Id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    FullPath                TEXT NOT NULL UNIQUE,
    SizeBytes               INTEGER NOT NULL DEFAULT 0,
    CreatedUtc              TEXT,
    ModifiedUtc             TEXT,
    AccessedUtc             TEXT,
    OwnerSid                TEXT,
    IsHidden                INTEGER NOT NULL DEFAULT 0,
    IsSystem                INTEGER NOT NULL DEFAULT 0,
    IsReparsePoint          INTEGER NOT NULL DEFAULT 0,
    HasAlternateDataStreams INTEGER NOT NULL DEFAULT 0,
    Sha256                  TEXT,
    PublisherFromSignature  TEXT,
    OwningProgramId         INTEGER REFERENCES Programs(Id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS IX_Files_OwningProgramId ON Files(OwningProgramId);
CREATE INDEX IF NOT EXISTS IX_Files_ModifiedUtc ON Files(ModifiedUtc);

CREATE TABLE IF NOT EXISTS RegistryEntries (
    Id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    Hive                TEXT NOT NULL,
    KeyPath             TEXT NOT NULL,
    ValueName           TEXT,
    ValueData           TEXT,
    LastWriteUtc        TEXT,
    OwningProgramId     INTEGER REFERENCES Programs(Id) ON DELETE SET NULL,
    UNIQUE(Hive, KeyPath, ValueName)
);
CREATE INDEX IF NOT EXISTS IX_Registry_OwningProgramId ON RegistryEntries(OwningProgramId);

CREATE TABLE IF NOT EXISTS ServicesAndTasks (
    Id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    Name                TEXT NOT NULL,
    Type                TEXT NOT NULL, -- Service | ScheduledTask | RunKey | StartupFolder
    BinaryPath          TEXT,
    OwningProgramId     INTEGER REFERENCES Programs(Id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS IX_ServicesAndTasks_OwningProgramId ON ServicesAndTasks(OwningProgramId);

-- Snapshot manifests: each install-time snapshot (pre/post) is a labeled
-- point-in-time capture. SnapshotItems stores the raw rows captured at
-- that moment, before they're diffed and folded into Files/RegistryEntries.
CREATE TABLE IF NOT EXISTS Snapshots (
    Id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ManifestId      TEXT NOT NULL UNIQUE,
    Label           TEXT NOT NULL,      -- pre-install | post-install
    TakenAtUtc      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS SnapshotItems (
    Id              INTEGER PRIMARY KEY AUTOINCREMENT,
    SnapshotId      INTEGER NOT NULL REFERENCES Snapshots(Id) ON DELETE CASCADE,
    ItemType        TEXT NOT NULL,      -- File | RegistryValue
    Path            TEXT NOT NULL,
    Fingerprint     TEXT                -- size+mtime hash for files, value-hash for registry
);
CREATE INDEX IF NOT EXISTS IX_SnapshotItems_SnapshotId ON SnapshotItems(SnapshotId);
CREATE INDEX IF NOT EXISTS IX_SnapshotItems_Path ON SnapshotItems(Path);

-- Quarantine ledger: nothing is hard-deleted on first pass. Every delete
-- action is recorded here with enough info to restore it.
CREATE TABLE IF NOT EXISTS QuarantineLedger (
    Id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    ProgramId           INTEGER REFERENCES Programs(Id) ON DELETE SET NULL,
    ItemType            TEXT NOT NULL,   -- File | Folder | RegistryKey | Service | Task
    OriginalPath        TEXT NOT NULL,
    QuarantinePath      TEXT,            -- filesystem items moved here
    RegBackupFile        TEXT,            -- .reg export path for registry items
    RiskLevelAtDelete    TEXT NOT NULL,
    QuarantinedUtc       TEXT NOT NULL DEFAULT (datetime('now')),
    PurgeAfterUtc        TEXT NOT NULL,
    Restored             INTEGER NOT NULL DEFAULT 0,
    Purged               INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS IX_Quarantine_PurgeAfterUtc ON QuarantineLedger(PurgeAfterUtc);
