// DeepPurge - Database Manager
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// Every other module (crawlers, association engine, diff engine, quarantine
// manager) talks to the outside world ONLY through this class. That's the
// "wiring" contract: nobody opens their own SQLite connection.

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Microsoft.Data.Sqlite;
using DeepPurge.Core.Models;

namespace DeepPurge.Core.Database
{
    public class DatabaseManager : IDisposable
    {
        private readonly SqliteConnection _connection;
        public string DbPath { get; }

        public DatabaseManager(string dbPath)
        {
            DbPath = dbPath;
            var dir = Path.GetDirectoryName(dbPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            _connection = new SqliteConnection($"Data Source={dbPath}");
            _connection.Open();
            ApplySchema();
        }

        private void ApplySchema()
        {
            string schemaSql = ReadEmbeddedOrSiblingSchema();
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = schemaSql;
            cmd.ExecuteNonQuery();
        }

        private string ReadEmbeddedOrSiblingSchema()
        {
            // Schema.sql is copied to the output directory as content (see .csproj).
            var candidate = Path.Combine(AppContext.BaseDirectory, "Database", "Schema.sql");
            if (File.Exists(candidate)) return File.ReadAllText(candidate);

            // Fallback: look next to the assembly directly.
            candidate = Path.Combine(AppContext.BaseDirectory, "Schema.sql");
            if (File.Exists(candidate)) return File.ReadAllText(candidate);

            throw new FileNotFoundException(
                "Schema.sql not found next to the executable. Ensure it is copied on build.");
        }

        // ---------------- Programs ----------------

        public long UpsertProgram(ProgramRecord p)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO Programs (DisplayName, Publisher, DisplayVersion, InstallLocation,
                                       UninstallString, InstallDateUtc, DiscoveryMethod, ConfidenceScore)
                VALUES ($name, $pub, $ver, $loc, $unstr, $instdate, $disc, $conf)
                RETURNING Id;";
            cmd.Parameters.AddWithValue("$name", p.DisplayName);
            cmd.Parameters.AddWithValue("$pub", (object?)p.Publisher ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$ver", (object?)p.DisplayVersion ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$loc", (object?)p.InstallLocation ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$unstr", (object?)p.UninstallString ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$instdate", (object?)p.InstallDateUtc?.ToString("o") ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$disc", p.Discovery.ToString());
            cmd.Parameters.AddWithValue("$conf", p.ConfidenceScore);
            var result = cmd.ExecuteScalar();
            return Convert.ToInt64(result);
        }

        public List<ProgramRecord> GetAllPrograms()
        {
            var list = new List<ProgramRecord>();
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = "SELECT Id, DisplayName, Publisher, DisplayVersion, InstallLocation, " +
                               "UninstallString, InstallDateUtc, DiscoveryMethod, ConfidenceScore FROM Programs;";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new ProgramRecord
                {
                    Id = reader.GetInt64(0),
                    DisplayName = reader.GetString(1),
                    Publisher = reader.IsDBNull(2) ? null : reader.GetString(2),
                    DisplayVersion = reader.IsDBNull(3) ? null : reader.GetString(3),
                    InstallLocation = reader.IsDBNull(4) ? null : reader.GetString(4),
                    UninstallString = reader.IsDBNull(5) ? null : reader.GetString(5),
                    InstallDateUtc = reader.IsDBNull(6) ? null : DateTime.Parse(reader.GetString(6)),
                    Discovery = Enum.Parse<DiscoveryMethod>(reader.GetString(7)),
                    ConfidenceScore = reader.GetDouble(8)
                });
            }
            return list;
        }

        // ---------------- Files ----------------

        public long UpsertFile(FileRecord f)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO Files (FullPath, SizeBytes, CreatedUtc, ModifiedUtc, AccessedUtc,
                                    OwnerSid, IsHidden, IsSystem, IsReparsePoint,
                                    HasAlternateDataStreams, Sha256, PublisherFromSignature, OwningProgramId)
                VALUES ($path, $size, $created, $modified, $accessed, $owner, $hidden, $system,
                        $reparse, $ads, $sha, $pub, $prog)
                ON CONFLICT(FullPath) DO UPDATE SET
                    SizeBytes=$size, ModifiedUtc=$modified, AccessedUtc=$accessed,
                    OwningProgramId=COALESCE($prog, OwningProgramId)
                RETURNING Id;";
            cmd.Parameters.AddWithValue("$path", f.FullPath);
            cmd.Parameters.AddWithValue("$size", f.SizeBytes);
            cmd.Parameters.AddWithValue("$created", f.CreatedUtc.ToString("o"));
            cmd.Parameters.AddWithValue("$modified", f.ModifiedUtc.ToString("o"));
            cmd.Parameters.AddWithValue("$accessed", f.AccessedUtc.ToString("o"));
            cmd.Parameters.AddWithValue("$owner", (object?)f.OwnerSid ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$hidden", f.IsHidden ? 1 : 0);
            cmd.Parameters.AddWithValue("$system", f.IsSystem ? 1 : 0);
            cmd.Parameters.AddWithValue("$reparse", f.IsReparsePoint ? 1 : 0);
            cmd.Parameters.AddWithValue("$ads", f.HasAlternateDataStreams ? 1 : 0);
            cmd.Parameters.AddWithValue("$sha", (object?)f.Sha256 ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$pub", (object?)f.PublisherFromSignature ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$prog", (object?)f.OwningProgramId ?? DBNull.Value);
            var result = cmd.ExecuteScalar();
            return Convert.ToInt64(result);
        }

        public void LinkFileToProgram(long fileId, long programId)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = "UPDATE Files SET OwningProgramId = $prog WHERE Id = $id;";
            cmd.Parameters.AddWithValue("$prog", programId);
            cmd.Parameters.AddWithValue("$id", fileId);
            cmd.ExecuteNonQuery();
        }

        // ---------------- Registry ----------------

        public long UpsertRegistryEntry(RegistryRecord r)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO RegistryEntries (Hive, KeyPath, ValueName, ValueData, LastWriteUtc, OwningProgramId)
                VALUES ($hive, $key, $vname, $vdata, $lw, $prog)
                ON CONFLICT(Hive, KeyPath, ValueName) DO UPDATE SET
                    ValueData=$vdata, LastWriteUtc=$lw,
                    OwningProgramId=COALESCE($prog, OwningProgramId)
                RETURNING Id;";
            cmd.Parameters.AddWithValue("$hive", r.Hive);
            cmd.Parameters.AddWithValue("$key", r.KeyPath);
            cmd.Parameters.AddWithValue("$vname", (object?)r.ValueName ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$vdata", (object?)r.ValueData ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$lw", (object?)r.LastWriteUtc?.ToString("o") ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$prog", (object?)r.OwningProgramId ?? DBNull.Value);
            var result = cmd.ExecuteScalar();
            return Convert.ToInt64(result);
        }

        // ---------------- Snapshots ----------------

        public long CreateSnapshot(SnapshotManifest manifest)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = @"INSERT INTO Snapshots (ManifestId, Label, TakenAtUtc)
                                 VALUES ($mid, $label, $taken) RETURNING Id;";
            cmd.Parameters.AddWithValue("$mid", manifest.ManifestId);
            cmd.Parameters.AddWithValue("$label", manifest.Label);
            cmd.Parameters.AddWithValue("$taken", manifest.TakenAtUtc.ToString("o"));
            return Convert.ToInt64(cmd.ExecuteScalar());
        }

        public void AddSnapshotItem(long snapshotId, string itemType, string path, string? fingerprint)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = @"INSERT INTO SnapshotItems (SnapshotId, ItemType, Path, Fingerprint)
                                 VALUES ($sid, $type, $path, $fp);";
            cmd.Parameters.AddWithValue("$sid", snapshotId);
            cmd.Parameters.AddWithValue("$type", itemType);
            cmd.Parameters.AddWithValue("$path", path);
            cmd.Parameters.AddWithValue("$fp", (object?)fingerprint ?? DBNull.Value);
            cmd.ExecuteNonQuery();
        }

        public HashSet<string> GetSnapshotPaths(long snapshotId)
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = "SELECT Path FROM SnapshotItems WHERE SnapshotId = $sid;";
            cmd.Parameters.AddWithValue("$sid", snapshotId);
            using var reader = cmd.ExecuteReader();
            while (reader.Read()) set.Add(reader.GetString(0));
            return set;
        }

        // ---------------- Quarantine ----------------

        public long AddQuarantineEntry(long? programId, string itemType, string originalPath,
            string? quarantinePath, string? regBackupFile, RiskLevel riskAtDelete, DateTime purgeAfterUtc)
        {
            using var cmd = _connection.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO QuarantineLedger (ProgramId, ItemType, OriginalPath, QuarantinePath,
                                               RegBackupFile, RiskLevelAtDelete, PurgeAfterUtc)
                VALUES ($prog, $type, $orig, $qpath, $regbak, $risk, $purge)
                RETURNING Id;";
            cmd.Parameters.AddWithValue("$prog", (object?)programId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$type", itemType);
            cmd.Parameters.AddWithValue("$orig", originalPath);
            cmd.Parameters.AddWithValue("$qpath", (object?)quarantinePath ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$regbak", (object?)regBackupFile ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$risk", riskAtDelete.ToString());
            cmd.Parameters.AddWithValue("$purge", purgeAfterUtc.ToString("o"));
            return Convert.ToInt64(cmd.ExecuteScalar());
        }

        public SqliteConnection RawConnection => _connection;

        public void Dispose()
        {
            _connection?.Dispose();
        }
    }
}
