// DeepPurge - Risk Scoring Engine
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// This is the module responsible for the promise "won't break anything else."
// Before ANY leftover is queued for deletion, it passes through here. The
// scorer cross-checks candidate items against every OTHER installed
// program's known files/registry entries - if a DLL or folder is referenced
// by more than one program's manifest, it is never auto-deleted.

using System.Collections.Generic;
using System.Linq;
using DeepPurge.Core.Models;

namespace DeepPurge.Core.Engine
{
    public class RiskScorer
    {
        private static readonly HashSet<string> KnownSharedRuntimeFolders = new(System.StringComparer.OrdinalIgnoreCase)
        {
            @"C:\Windows",
            @"C:\Windows\System32",
            @"C:\Windows\SysWOW64",
            @"C:\Program Files\Common Files",
            @"C:\Program Files (x86)\Common Files",
            @"C:\ProgramData\Package Cache" // shared VC++ redistributable cache
        };

        /// <summary>
        /// Scores a single candidate leftover file/folder for deletion safety.
        /// `allProgramFilePaths` should be every FullPath owned by EVERY OTHER
        /// installed program currently in the index (not just the one being
        /// uninstalled) - this is the cross-check that prevents collateral damage.
        /// </summary>
        public RiskLevel ScoreFileForDeletion(FileRecord candidate, IReadOnlySet<string> allOtherProgramFilePaths)
        {
            foreach (var protectedRoot in KnownSharedRuntimeFolders)
            {
                if (candidate.FullPath.StartsWith(protectedRoot, System.StringComparison.OrdinalIgnoreCase))
                    return RiskLevel.DoNotTouch;
            }

            if (allOtherProgramFilePaths.Contains(candidate.FullPath))
                return RiskLevel.DoNotTouch; // Another installed program also owns this exact path.

            if (candidate.IsSystem)
                return RiskLevel.SharedComponentCaution;

            if (candidate.HasAlternateDataStreams)
                return RiskLevel.Unknown; // Worth a human look before auto-deleting.

            // Files strongly tied to a program via SnapshotDiff (perfect discovery)
            // and not flagged by any of the above are the safest category.
            return RiskLevel.SafeToDelete;
        }

        public RiskLevel ScoreRegistryKeyForDeletion(RegistryRecord candidate, IReadOnlySet<string> allOtherProgramRegistryKeys)
        {
            var fullKey = $"{candidate.Hive}\\{candidate.KeyPath}";

            // Never touch core OS keys even if something matched oddly.
            if (fullKey.StartsWith(@"HKLM\SYSTEM", System.StringComparison.OrdinalIgnoreCase) ||
                fullKey.StartsWith(@"HKLM\SOFTWARE\Microsoft\Windows NT", System.StringComparison.OrdinalIgnoreCase))
            {
                return RiskLevel.DoNotTouch;
            }

            if (allOtherProgramRegistryKeys.Contains(fullKey))
                return RiskLevel.DoNotTouch;

            return RiskLevel.SafeToDelete;
        }

        /// <summary>
        /// Builds the full leftover findings list for a program, ready to
        /// present to the user before any deletion happens.
        /// </summary>
        public List<LeftoverFinding> BuildFindings(
            ProgramRecord program,
            IEnumerable<FileRecord> candidateFiles,
            IEnumerable<RegistryRecord> candidateRegistryEntries,
            IReadOnlySet<string> allOtherProgramFilePaths,
            IReadOnlySet<string> allOtherProgramRegistryKeys)
        {
            var findings = new List<LeftoverFinding>();

            foreach (var file in candidateFiles)
            {
                var risk = ScoreFileForDeletion(file, allOtherProgramFilePaths);
                findings.Add(new LeftoverFinding
                {
                    ProgramId = program.Id,
                    ProgramName = program.DisplayName,
                    ItemType = "File",
                    Path = file.FullPath,
                    Risk = risk,
                    RiskReason = ExplainFileRisk(risk)
                });
            }

            foreach (var reg in candidateRegistryEntries)
            {
                var risk = ScoreRegistryKeyForDeletion(reg, allOtherProgramRegistryKeys);
                findings.Add(new LeftoverFinding
                {
                    ProgramId = program.Id,
                    ProgramName = program.DisplayName,
                    ItemType = "RegistryKey",
                    Path = $"{reg.Hive}\\{reg.KeyPath}",
                    Risk = risk,
                    RiskReason = ExplainRegistryRisk(risk)
                });
            }

            return findings.OrderByDescending(f => f.Risk).ToList();
        }

        private static string ExplainFileRisk(RiskLevel risk) => risk switch
        {
            RiskLevel.DoNotTouch => "Path is a protected system location or is also owned by another installed program.",
            RiskLevel.SharedComponentCaution => "Marked as a system file by the OS; review before deleting.",
            RiskLevel.Unknown => "Contains alternate data streams; recommend manual review.",
            RiskLevel.SafeToDelete => "Uniquely owned by this program with no conflicting references found.",
            _ => "Unclassified."
        };

        private static string ExplainRegistryRisk(RiskLevel risk) => risk switch
        {
            RiskLevel.DoNotTouch => "Core OS key or referenced by another installed program.",
            RiskLevel.SafeToDelete => "Uniquely owned by this program.",
            _ => "Unclassified."
        };
    }
}
