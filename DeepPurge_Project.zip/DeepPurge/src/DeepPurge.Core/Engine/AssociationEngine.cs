// DeepPurge - Association Engine (Layer 3)
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// Answers the hard question: "which installed program owns this file /
// registry key?" Combines several independent signals into a confidence
// score. This is what makes the scanner "smart" rather than a dumb crawler:
// it works even for programs installed long before DeepPurge existed
// (Pre-installed software), where no snapshot manifest is available.
//
// Signals used (weights are intentionally conservative - false positives
// here mean deleting something you shouldn't, so we bias toward caution):
//   1. Exact path containment under the program's InstallLocation   (0.50)
//   2. Publisher name match (file's signed CompanyName == program's Publisher) (0.25)
//   3. Timestamp clustering (file created within +/- 5 min of InstallDateUtc) (0.15)
//   4. Fuzzy name match between folder/file name and DisplayName    (0.10)

using System;
using System.Collections.Generic;
using System.Linq;
using DeepPurge.Core.Models;

namespace DeepPurge.Core.Engine
{
    public class AssociationEngine
    {
        private const double PathContainmentWeight = 0.50;
        private const double PublisherMatchWeight = 0.25;
        private const double TimestampClusterWeight = 0.15;
        private const double FuzzyNameWeight = 0.10;

        private static readonly TimeSpan TimestampClusterWindow = TimeSpan.FromMinutes(5);

        /// <summary>
        /// Scores how likely it is that `file` belongs to `program`. Returns
        /// 0.0-1.0. Callers should only auto-link above a chosen threshold
        /// (recommended default: 0.60) and should surface anything between
        /// 0.30 and 0.60 to the user as "possible match" rather than silently
        /// assuming ownership.
        /// </summary>
        public double ScoreFileAssociation(FileRecord file, ProgramRecord program)
        {
            double score = 0.0;

            if (!string.IsNullOrEmpty(program.InstallLocation) &&
                file.FullPath.StartsWith(program.InstallLocation!, StringComparison.OrdinalIgnoreCase))
            {
                score += PathContainmentWeight;
            }

            if (!string.IsNullOrEmpty(program.Publisher) &&
                !string.IsNullOrEmpty(file.PublisherFromSignature) &&
                string.Equals(program.Publisher!.Trim(), file.PublisherFromSignature!.Trim(),
                    StringComparison.OrdinalIgnoreCase))
            {
                score += PublisherMatchWeight;
            }

            if (program.InstallDateUtc.HasValue)
            {
                var delta = (file.CreatedUtc - program.InstallDateUtc.Value).Duration();
                if (delta <= TimestampClusterWindow)
                    score += TimestampClusterWeight;
            }

            var fuzzy = FuzzyNameSimilarity(
                System.IO.Path.GetFileName(file.FullPath.TrimEnd('\\')),
                program.DisplayName);
            score += FuzzyNameWeight * fuzzy;

            return Math.Min(score, 1.0);
        }

        /// <summary>
        /// For a candidate file with no strong single-program match, find the
        /// best-fitting program among all known programs. Returns null if
        /// nothing clears the minimum floor (0.30), meaning it should be
        /// reported as "orphaned / unknown owner" rather than force-assigned.
        /// </summary>
        public (ProgramRecord? Program, double Score) FindBestMatch(FileRecord file, IEnumerable<ProgramRecord> programs)
        {
            ProgramRecord? best = null;
            double bestScore = 0.0;

            foreach (var program in programs)
            {
                var score = ScoreFileAssociation(file, program);
                if (score > bestScore)
                {
                    bestScore = score;
                    best = program;
                }
            }

            return bestScore >= 0.30 ? (best, bestScore) : (null, 0.0);
        }

        /// <summary>
        /// Groups a flat set of "orphaned" (unowned) files into clusters that
        /// likely represent a single uninstalled/unknown program, using
        /// shared parent-folder + timestamp proximity. Used when scanning
        /// leftovers from software that was removed before DeepPurge was
        /// ever installed (so there's no Uninstall-registry breadcrumb left
        /// at all) - pure filesystem archaeology.
        /// </summary>
        public List<List<FileRecord>> ClusterOrphanFiles(IEnumerable<FileRecord> orphanFiles)
        {
            var clusters = new List<List<FileRecord>>();
            var byParentDir = orphanFiles.GroupBy(f => System.IO.Path.GetDirectoryName(f.FullPath) ?? string.Empty);

            foreach (var group in byParentDir)
            {
                // Within a shared parent directory, split further by creation-time
                // proximity so unrelated files that happen to share a folder
                // (e.g. a general cache dir) don't get merged into one "program".
                var sorted = group.OrderBy(f => f.CreatedUtc).ToList();
                var current = new List<FileRecord>();
                DateTime? lastTimestamp = null;

                foreach (var file in sorted)
                {
                    if (lastTimestamp.HasValue &&
                        (file.CreatedUtc - lastTimestamp.Value) > TimestampClusterWindow)
                    {
                        if (current.Count > 0) clusters.Add(current);
                        current = new List<FileRecord>();
                    }
                    current.Add(file);
                    lastTimestamp = file.CreatedUtc;
                }
                if (current.Count > 0) clusters.Add(current);
            }

            return clusters;
        }

        /// <summary>
        /// Simple normalized token-overlap fuzzy match (Jaccard on word tokens),
        /// good enough to catch "Adobe Acrobat" vs "Acrobat Reader DC" style
        /// renames without pulling in an external NLP dependency.
        /// </summary>
        private static double FuzzyNameSimilarity(string a, string b)
        {
            var tokensA = Tokenize(a);
            var tokensB = Tokenize(b);
            if (tokensA.Count == 0 || tokensB.Count == 0) return 0.0;

            var intersection = tokensA.Intersect(tokensB, StringComparer.OrdinalIgnoreCase).Count();
            var union = tokensA.Union(tokensB, StringComparer.OrdinalIgnoreCase).Count();
            return union == 0 ? 0.0 : (double)intersection / union;
        }

        private static HashSet<string> Tokenize(string s)
        {
            var cleaned = new string(s.Select(c => char.IsLetterOrDigit(c) ? c : ' ').ToArray());
            return cleaned.Split(' ', StringSplitOptions.RemoveEmptyEntries)
                          .Where(t => t.Length > 1)
                          .Select(t => t.ToLowerInvariant())
                          .ToHashSet();
        }
    }
}
