// DeepPurge - Snapshot Diff Engine
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// The most reliable discovery path: take a full snapshot immediately before
// an installer runs, and another immediately after. Everything new in the
// "after" set that wasn't in the "before" set was created by that install -
// no fuzzy matching or guessing required. This is what a background watcher
// service should trigger automatically when it detects an installer process
// starting (e.g. by watching for new processes with "setup"/"install" in the
// name, or hooking the Windows Installer service).

using System;
using System.Collections.Generic;
using System.Linq;
using DeepPurge.Core.Database;
using DeepPurge.Core.Models;
using DeepPurge.Core.Scanners;

namespace DeepPurge.Core.Engine
{
    public class SnapshotDiffEngine
    {
        private readonly DatabaseManager _db;
        private readonly FileSystemCrawler _fsCrawler;
        private readonly RegistryCrawler _regCrawler;

        public SnapshotDiffEngine(DatabaseManager db, FileSystemCrawler fsCrawler, RegistryCrawler regCrawler)
        {
            _db = db;
            _fsCrawler = fsCrawler;
            _regCrawler = regCrawler;
        }

        /// <summary>
        /// Take a snapshot right before an installer runs. Scope should be the
        /// priority install zones (fast) rather than a full-drive sweep -
        /// installers essentially never write outside these locations.
        /// </summary>
        public long TakePreInstallSnapshot()
        {
            var manifest = new SnapshotManifest { Label = "pre-install", TakenAtUtc = DateTime.UtcNow };
            var snapshotId = _db.CreateSnapshot(manifest);

            foreach (var file in _fsCrawler.Crawl(FileSystemCrawler.DefaultPriorityRoots, fullDriveSweep: false))
            {
                _db.AddSnapshotItem(snapshotId, "File", file.FullPath, Fingerprint(file));
            }

            foreach (var reg in _regCrawler.CrawlInstallRelevantKeys())
            {
                var regPath = $"{reg.Hive}\\{reg.KeyPath}\\{reg.ValueName}";
                _db.AddSnapshotItem(snapshotId, "RegistryValue", regPath, reg.ValueData);
            }

            return snapshotId;
        }

        /// <summary>
        /// Take the matching post-install snapshot, diff against the pre-install
        /// baseline, and materialize a new ProgramRecord whose Files/Registry
        /// links are exactly what the installer created. This is the
        /// "DiscoveryMethod.SnapshotDiff" path - the highest-confidence source
        /// the Association Engine can ever get.
        /// </summary>
        public ProgramRecord TakePostInstallSnapshotAndDiff(long preSnapshotId, string programNameHint)
        {
            var beforePaths = _db.GetSnapshotPaths(preSnapshotId);

            var manifest = new SnapshotManifest { Label = "post-install", TakenAtUtc = DateTime.UtcNow };
            var postSnapshotId = _db.CreateSnapshot(manifest);

            var newFiles = new List<FileRecord>();
            foreach (var file in _fsCrawler.Crawl(FileSystemCrawler.DefaultPriorityRoots, fullDriveSweep: false))
            {
                _db.AddSnapshotItem(postSnapshotId, "File", file.FullPath, Fingerprint(file));
                if (!beforePaths.Contains(file.FullPath))
                    newFiles.Add(file);
            }

            var newRegistryEntries = new List<RegistryRecord>();
            foreach (var reg in _regCrawler.CrawlInstallRelevantKeys())
            {
                var regPath = $"{reg.Hive}\\{reg.KeyPath}\\{reg.ValueName}";
                _db.AddSnapshotItem(postSnapshotId, "RegistryValue", regPath, reg.ValueData);
                if (!beforePaths.Contains(regPath))
                    newRegistryEntries.Add(reg);
            }

            // Best-effort: infer install location as the shortest common
            // directory prefix among the new files (typically Program Files\AppName).
            var inferredInstallLocation = InferCommonRoot(newFiles.Select(f => f.FullPath));

            var program = new ProgramRecord
            {
                DisplayName = programNameHint,
                InstallLocation = inferredInstallLocation,
                InstallDateUtc = DateTime.UtcNow,
                Discovery = DiscoveryMethod.SnapshotDiff,
                ConfidenceScore = 1.0 // Exact diff - no ambiguity.
            };

            var programId = _db.UpsertProgram(program);
            program.Id = programId;

            foreach (var file in newFiles)
            {
                file.OwningProgramId = programId;
                var fileId = _db.UpsertFile(file);
                program.FileIds.Add(fileId);
            }

            foreach (var reg in newRegistryEntries)
            {
                reg.OwningProgramId = programId;
                var regId = _db.UpsertRegistryEntry(reg);
                program.RegistryIds.Add(regId);
            }

            return program;
        }

        private static string Fingerprint(FileRecord f) => $"{f.SizeBytes}:{f.ModifiedUtc.Ticks}";

        private static string? InferCommonRoot(IEnumerable<string> paths)
        {
            var list = paths.ToList();
            if (list.Count == 0) return null;

            var segments = list.Select(p => p.Split('\\')).ToList();
            var minLength = segments.Min(s => s.Length);
            var common = new List<string>();

            for (int i = 0; i < minLength; i++)
            {
                var candidate = segments[0][i];
                if (segments.All(s => string.Equals(s[i], candidate, StringComparison.OrdinalIgnoreCase)))
                    common.Add(candidate);
                else
                    break;
            }

            return common.Count > 0 ? string.Join('\\', common) : null;
        }
    }
}
