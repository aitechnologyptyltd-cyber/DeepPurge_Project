// DeepPurge - Threat Scan Gate
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// Runs every file through TWO independent, legally-redistributable/already-
// present engines before it is ever quarantined or deleted:
//
//   1. ClamAV (clamscan.exe)  - open-source (GPL), redistributable, signature-based
//   2. Windows Defender (MpCmdRun.exe) - already on every Windows 10/11 machine,
//      called via its command-line scan interface, no bundling required
//
// Rationale for NOT bundling four proprietary AV engines: only ClamAV is
// legally redistributable; commercial engines (Norton/Avast/Bitdefender/
// Kaspersky, etc.) require a licensing agreement to embed, and running
// multiple full AV engines simultaneously causes real-time-protection
// conflicts (file-lock contention, engines quarantining each other's
// files). Two independent, legitimately-available engines give a genuine
// second opinion without those problems.
//
// This gate is a HARD STOP: if either engine flags a file, DeepPurge does
// NOT quarantine or delete it as part of the normal safe-cleanup flow. It
// is surfaced to the user as "quarantined for a different reason" - malware,
// not "leftover" - so the user can decide (e.g. hand it to their main AV,
// or delete it deliberately knowing what it is).

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace DeepPurge.Core.Engine
{
    public enum ThreatVerdict
    {
        Clean,
        FlaggedByClamAV,
        FlaggedByDefender,
        FlaggedByBoth,
        ScanUnavailable   // engine missing/not installed - treated as "proceed with caution", never as "clean"
    }

    public class ThreatScanResult
    {
        public ThreatVerdict Verdict { get; set; }
        public string? ClamAvSignatureName { get; set; }
        public string? DefenderThreatName { get; set; }
        public string Path { get; set; } = string.Empty;

        public bool IsInfected => Verdict == ThreatVerdict.FlaggedByClamAV ||
                                   Verdict == ThreatVerdict.FlaggedByDefender ||
                                   Verdict == ThreatVerdict.FlaggedByBoth;
    }

    public class ThreatScanGate
    {
        // Typical install locations - overridable via constructor for
        // portable/bundled deployments (see installer/install.sh, which
        // fetches ClamAV for Windows into a known local path).
        private readonly string _clamscanPath;
        private readonly string _mpCmdRunPath;

        public ThreatScanGate(
            string? clamscanPath = null,
            string? mpCmdRunPath = null)
        {
            _clamscanPath = clamscanPath ?? @"C:\Program Files\DeepPurge\ClamAV\clamscan.exe";
            _mpCmdRunPath = mpCmdRunPath ?? FindDefenderMpCmdRun();
        }

        /// <summary>
        /// Scans a single file with both engines. Call this immediately
        /// before QuarantineManager.QuarantineFile for every candidate.
        /// </summary>
        public ThreatScanResult ScanFile(string path)
        {
            var result = new ThreatScanResult { Path = path };

            if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows) || !File.Exists(path))
            {
                result.Verdict = ThreatVerdict.ScanUnavailable;
                return result;
            }

            bool clamFlag = false, defenderFlag = false;

            if (File.Exists(_clamscanPath))
            {
                var (exitCode, stdout) = RunProcess(_clamscanPath, $"--no-summary \"{path}\"");
                // clamscan exit codes: 0 = clean, 1 = virus found, 2 = error
                if (exitCode == 1)
                {
                    clamFlag = true;
                    result.ClamAvSignatureName = ExtractClamSignature(stdout);
                }
            }

            if (_mpCmdRunPath != null && File.Exists(_mpCmdRunPath))
            {
                // -Scan -ScanType 3 = custom/targeted scan of a specific path
                var (exitCode, stdout) = RunProcess(_mpCmdRunPath, $"-Scan -ScanType 3 -File \"{path}\"");
                // MpCmdRun does not always return a clean nonzero/zero contract across
                // versions; treat any mention of "Threat" in stdout as a flag rather
                // than relying solely on exit code, since behaviour has changed
                // across Defender platform updates.
                if (exitCode != 0 || stdout.Contains("Threat", StringComparison.OrdinalIgnoreCase))
                {
                    defenderFlag = true;
                    result.DefenderThreatName = ExtractDefenderThreatName(stdout);
                }
            }

            if (clamFlag && defenderFlag) result.Verdict = ThreatVerdict.FlaggedByBoth;
            else if (clamFlag) result.Verdict = ThreatVerdict.FlaggedByClamAV;
            else if (defenderFlag) result.Verdict = ThreatVerdict.FlaggedByDefender;
            else if (!File.Exists(_clamscanPath) && _mpCmdRunPath == null) result.Verdict = ThreatVerdict.ScanUnavailable;
            else result.Verdict = ThreatVerdict.Clean;

            return result;
        }

        /// <summary>
        /// Joins the two engines' local signature/definition update commands
        /// into a single call so both databases stay current together. This
        /// is the "combined DB" outcome that's actually achievable: not a
        /// literal merged signature file (each vendor's format is proprietary
        /// and undocumented on purpose), but a single DeepPurge command that
        /// updates both engines' own databases in one step.
        /// </summary>
        public void UpdateAllSignatureDatabases()
        {
            var freshclam = Path.Combine(Path.GetDirectoryName(_clamscanPath) ?? "", "freshclam.exe");
            if (File.Exists(freshclam))
                RunProcess(freshclam, "");

            if (_mpCmdRunPath != null && File.Exists(_mpCmdRunPath))
                RunProcess(_mpCmdRunPath, "-SignatureUpdate");
        }

        private static string? FindDefenderMpCmdRun()
        {
            // MpCmdRun.exe lives under a version-numbered folder that changes
            // with platform updates; search the standard Defender directory.
            var root = @"C:\ProgramData\Microsoft\Windows Defender\Platform";
            if (!Directory.Exists(root)) return null;

            try
            {
                var newest = new DirectoryInfo(root)
                    .GetDirectories()
                    .OrderByDescending(d => d.Name)
                    .FirstOrDefault();
                if (newest == null) return null;

                var candidate = Path.Combine(newest.FullName, "MpCmdRun.exe");
                return File.Exists(candidate) ? candidate : null;
            }
            catch
            {
                return null;
            }
        }

        private static string? ExtractClamSignature(string stdout)
        {
            // clamscan output line format: "<path>: <Signature.Name> FOUND"
            foreach (var line in stdout.Split('\n'))
            {
                if (line.Contains("FOUND"))
                    return line.Substring(line.IndexOf(':') + 1).Replace("FOUND", "").Trim();
            }
            return null;
        }

        private static string? ExtractDefenderThreatName(string stdout)
        {
            foreach (var line in stdout.Split('\n'))
            {
                if (line.Contains("Threat", StringComparison.OrdinalIgnoreCase))
                    return line.Trim();
            }
            return null;
        }

        private static (int ExitCode, string StdOut) RunProcess(string fileName, string arguments)
        {
            using var proc = Process.Start(new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            });

            if (proc == null) return (-1, string.Empty);
            string stdout = proc.StandardOutput.ReadToEnd();
            proc.WaitForExit();
            return (proc.ExitCode, stdout);
        }
    }
}
