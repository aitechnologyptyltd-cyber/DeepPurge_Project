// DeepPurge - Quarantine Manager & Process/Service Terminator
// Sole Developer & Architect: Francois Nel (SA ID: 8708275089084)
//
// Nothing is ever hard-deleted on the first pass. Files/folders are moved
// into a quarantine directory; registry keys are exported to a .reg backup
// file before being removed. Everything is logged to QuarantineLedger with
// a PurgeAfterUtc so a scheduled cleanup job can permanently remove items
// only after the retention window has passed with no restore request.

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using DeepPurge.Core.Database;
using DeepPurge.Core.Models;

namespace DeepPurge.Core.Engine
{
    /// <summary>
    /// Thrown when ThreatScanGate flags a file as infected during the
    /// pre-quarantine scan. Callers should catch this separately from
    /// ordinary quarantine failures: it means "this isn't a leftover,
    /// it's malware" and should be surfaced to the user distinctly.
    /// </summary>
    public class ThreatDetectedException : Exception
    {
        public ThreatScanResult ScanResult { get; }
        public ThreatDetectedException(ThreatScanResult result)
            : base($"Threat scan flagged '{result.Path}' ({result.Verdict}) - refusing to quarantine or delete.")
        {
            ScanResult = result;
        }
    }

    public class QuarantineManager
    {
        private readonly DatabaseManager _db;
        private readonly string _quarantineRoot;
        private readonly ThreatScanGate _threatScanGate;
        public int RetentionDays { get; set; } = 14;

        public QuarantineManager(DatabaseManager db, string quarantineRoot, ThreatScanGate? threatScanGate = null)
        {
            _db = db;
            _quarantineRoot = quarantineRoot;
            _threatScanGate = threatScanGate ?? new ThreatScanGate();
            Directory.CreateDirectory(_quarantineRoot);
        }

        /// <summary>
        /// Moves a file/folder into quarantine rather than deleting it.
        /// Only proceeds for RiskLevel.SafeToDelete or LikelySafe - callers
        /// must not invoke this for DoNotTouch/Unknown/SharedComponentCaution
        /// items without explicit user override.
        ///
        /// Before anything is moved, the file is run through the
        /// ThreatScanGate (ClamAV + Windows Defender). If either engine
        /// flags it, this throws ThreatDetectedException instead of
        /// proceeding - a file identified as malware is a different problem
        /// than a leftover, and is not silently folded into the normal
        /// uninstall-cleanup flow.
        /// </summary>
        public void QuarantineFile(long programId, string originalPath, RiskLevel risk)
        {
            if (risk == RiskLevel.DoNotTouch)
                throw new InvalidOperationException($"Refusing to quarantine a DoNotTouch item: {originalPath}");

            if (File.Exists(originalPath))
            {
                var scanResult = _threatScanGate.ScanFile(originalPath);
                if (scanResult.IsInfected)
                    throw new ThreatDetectedException(scanResult);
            }

            var destName = $"{Guid.NewGuid():N}_{Path.GetFileName(originalPath)}";
            var destPath = Path.Combine(_quarantineRoot, destName);

            if (File.Exists(originalPath))
                File.Move(originalPath, destPath, overwrite: false);
            else if (Directory.Exists(originalPath))
                Directory.Move(originalPath, destPath);
            else
                return; // Already gone; nothing to do.

            _db.AddQuarantineEntry(
                programId, File.Exists(destPath) ? "File" : "Folder",
                originalPath, destPath, regBackupFile: null,
                riskAtDelete: risk, purgeAfterUtc: DateTime.UtcNow.AddDays(RetentionDays));
        }

        /// <summary>
        /// Exports a registry key to a .reg file (so it can be re-imported)
        /// then deletes it. Uses reg.exe rather than raw P/Invoke deletion so
        /// the backup format is the same one a user could double-click to
        /// restore manually, independent of DeepPurge itself.
        /// </summary>
        public void QuarantineRegistryKey(long programId, string hive, string keyPath, RiskLevel risk)
        {
            if (risk == RiskLevel.DoNotTouch)
                throw new InvalidOperationException($"Refusing to quarantine a DoNotTouch key: {hive}\\{keyPath}");

            if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                throw new PlatformNotSupportedException("Registry operations require Windows.");

            var backupFile = Path.Combine(_quarantineRoot, $"{Guid.NewGuid():N}.reg");
            var fullKeyArg = $"{hive}\\{keyPath}";

            RunProcess("reg.exe", $"export \"{fullKeyArg}\" \"{backupFile}\" /y");
            RunProcess("reg.exe", $"delete \"{fullKeyArg}\" /f");

            _db.AddQuarantineEntry(
                programId, "RegistryKey", fullKeyArg, quarantinePath: null,
                regBackupFile: backupFile, riskAtDelete: risk,
                purgeAfterUtc: DateTime.UtcNow.AddDays(RetentionDays));
        }

        /// <summary>Restores a previously quarantined item using its ledger entry.</summary>
        public void Restore(long quarantineLedgerId)
        {
            using var cmd = _db.RawConnection.CreateCommand();
            cmd.CommandText = "SELECT ItemType, OriginalPath, QuarantinePath, RegBackupFile FROM QuarantineLedger WHERE Id = $id AND Purged = 0;";
            cmd.Parameters.AddWithValue("$id", quarantineLedgerId);
            using var reader = cmd.ExecuteReader();
            if (!reader.Read()) return;

            var itemType = reader.GetString(0);
            var originalPath = reader.GetString(1);
            var quarantinePath = reader.IsDBNull(2) ? null : reader.GetString(2);
            var regBackupFile = reader.IsDBNull(3) ? null : reader.GetString(3);

            if (itemType == "File" && quarantinePath != null && File.Exists(quarantinePath))
                File.Move(quarantinePath, originalPath, overwrite: false);
            else if (itemType == "Folder" && quarantinePath != null && Directory.Exists(quarantinePath))
                Directory.Move(quarantinePath, originalPath);
            else if (itemType == "RegistryKey" && regBackupFile != null && File.Exists(regBackupFile))
                RunProcess("reg.exe", $"import \"{regBackupFile}\"");

            using var update = _db.RawConnection.CreateCommand();
            update.CommandText = "UPDATE QuarantineLedger SET Restored = 1 WHERE Id = $id;";
            update.Parameters.AddWithValue("$id", quarantineLedgerId);
            update.ExecuteNonQuery();
        }

        /// <summary>
        /// Scheduled job: permanently purges quarantine entries whose retention
        /// window has passed and were never restored. Call this from Task
        /// Scheduler (the installer sets this up automatically) rather than
        /// on every run.
        /// </summary>
        public void PurgeExpired()
        {
            using var cmd = _db.RawConnection.CreateCommand();
            cmd.CommandText = @"SELECT Id, QuarantinePath FROM QuarantineLedger
                                 WHERE Purged = 0 AND Restored = 0 AND PurgeAfterUtc <= $now;";
            cmd.Parameters.AddWithValue("$now", DateTime.UtcNow.ToString("o"));

            using var reader = cmd.ExecuteReader();
            var toPurge = new System.Collections.Generic.List<(long Id, string? Path)>();
            while (reader.Read())
                toPurge.Add((reader.GetInt64(0), reader.IsDBNull(1) ? null : reader.GetString(1)));
            reader.Close();

            foreach (var (id, path) in toPurge)
            {
                try
                {
                    if (path != null && File.Exists(path)) File.Delete(path);
                    else if (path != null && Directory.Exists(path)) Directory.Delete(path, recursive: true);
                }
                catch { /* best-effort; leave for next run */ }

                using var update = _db.RawConnection.CreateCommand();
                update.CommandText = "UPDATE QuarantineLedger SET Purged = 1 WHERE Id = $id;";
                update.Parameters.AddWithValue("$id", id);
                update.ExecuteNonQuery();
            }
        }

        private static void RunProcess(string fileName, string arguments)
        {
            using var proc = Process.Start(new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            });
            proc?.WaitForExit();
        }
    }

    /// <summary>
    /// Ensures nothing belonging to the program being uninstalled is still
    /// running/locking files before quarantine/deletion is attempted -
    /// otherwise Windows will simply refuse to delete or move locked files.
    /// </summary>
    public class ProcessTerminator
    {
        public void StopServiceIfRunning(string serviceName)
        {
            RunProcess("sc.exe", $"stop \"{serviceName}\"");
        }

        public void KillProcessesByExecutablePath(string exePathPrefix)
        {
            foreach (var process in Process.GetProcesses())
            {
                try
                {
                    var path = process.MainModule?.FileName;
                    if (path != null && path.StartsWith(exePathPrefix, StringComparison.OrdinalIgnoreCase))
                    {
                        process.Kill(entireProcessTree: true);
                        process.WaitForExit(5000);
                    }
                }
                catch
                {
                    // Access denied on some system processes is expected; skip.
                }
            }
        }

        public void DisableScheduledTask(string taskName)
        {
            RunProcess("schtasks.exe", $"/Change /TN \"{taskName}\" /DISABLE");
        }

        public void DeleteScheduledTask(string taskName)
        {
            RunProcess("schtasks.exe", $"/Delete /TN \"{taskName}\" /F");
        }

        private static void RunProcess(string fileName, string arguments)
        {
            using var proc = Process.Start(new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            });
            proc?.WaitForExit();
        }
    }
}
