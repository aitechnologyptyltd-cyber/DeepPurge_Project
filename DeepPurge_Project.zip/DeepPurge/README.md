# DeepPurge — Deep System Uninstaller & Residual Cleaner

**Sole Developer & Architect:** Francois Nel (South Africa)

DeepPurge is a maximum-depth Windows uninstaller and leftover-cleanup engine.
Unlike the built-in Windows uninstaller (which only removes what the original
app's own uninstall script bothers to clean up), DeepPurge maintains a live
index of every file, registry entry, service, and scheduled task on the
system, tied back to the program that owns it — so when you uninstall
something, it's actually gone: no orphaned folders, no dead registry keys, no
zombie services.

## How it works (three discovery paths)

1. **Snapshot Diff (gold standard)** — take a system snapshot immediately
   before running an installer, another immediately after. The diff is exact:
   everything new was created by that install. No guessing.
2. **Uninstall-Registry + Association Engine** — for software already
   installed before DeepPurge existed, cross-reference the Windows
   `Uninstall` registry keys with a full filesystem crawl, scoring each
   file's likely owner using path containment, publisher signature match,
   install-timestamp clustering, and fuzzy name matching.
3. **Orphan Clustering** — leftovers from software uninstalled so long ago
   there's no registry breadcrumb at all get grouped by folder + timestamp
   proximity into "possible former program" clusters for manual review.

Every candidate leftover is **risk-scored** before anything happens to it —
cross-checked against every other installed program's files/registry keys, so
shared components are never deleted. Before a file is quarantined it also
passes through the **Threat Scan Gate**, which checks it with both ClamAV
(bundled, open-source) and Windows Defender (already on the system) — if
either flags it as malware, DeepPurge stops and leaves it alone rather than
treating it as an ordinary leftover. Nothing is ever hard-deleted on the
first pass: files move to quarantine, registry keys are exported to `.reg`
backups, both restorable for 14 days before permanent purge.

## Repository layout

```
DeepPurge/
├── DeepPurge.sln
├── src/
│   ├── DeepPurge.Core/           Class library — all engine logic
│   │   ├── Models/               Data models (FileRecord, ProgramRecord, etc.)
│   │   ├── Database/             SQLite schema + DatabaseManager (the wiring hub)
│   │   ├── Scanners/             FileSystemCrawler, RegistryCrawler
│   │   └── Engine/                AssociationEngine, SnapshotDiffEngine,
│   │                               RiskScorer, QuarantineManager, ProcessTerminator,
│   │                               ThreatScanGate
│   └── DeepPurge.CLI/             Console entry point, wires every module together
├── installer/
│   └── install.sh                 Git Bash installer: builds from source, installs, schedules cleanup
└── docs/
    └── DeepPurge_Full_Documentation.pdf
```

## Building & installing

Prerequisites: **.NET 8 SDK**, Windows 10/11 x64, Git Bash.

```bash
git clone <this repo, or just unzip the release>
cd DeepPurge
bash installer/install.sh
```

The installer restores packages, publishes a self-contained x64 build,
copies it to `C:\Program Files\DeepPurge`, creates a Start Menu shortcut,
and registers a daily scheduled task to purge expired quarantine items.

## Usage

```
DeepPurge.exe scan-existing              Deep scan + associate pre-installed software
DeepPurge.exe snapshot start             Take a pre-install snapshot (run before an installer)
DeepPurge.exe snapshot finish <id> "<Name>"   Diff post-install snapshot, index the new program
DeepPurge.exe list                       List all indexed programs
DeepPurge.exe uninstall <programId>      Full uninstall + leftover cleanup with risk scoring
DeepPurge.exe restore <quarantineId>     Restore a quarantined item within the retention window
DeepPurge.exe purge-expired              Permanently remove quarantine items past retention
DeepPurge.exe scan-threats <filePath>    Scan a single file with ClamAV + Windows Defender
DeepPurge.exe update-threat-db            Update ClamAV signatures + Windows Defender definitions
```

**Run as Administrator.** DeepPurge needs elevation to see hidden/system
files across all user profiles, read other users' registry hives, and
stop services/kill locked-file-holding processes.

## Honest scope note

This is a real, working foundation: the crawlers, database, association
engine, risk scorer, and quarantine system are fully implemented and wired
together. Two things are intentionally left as stubs for you to wire up per
your own needs before this becomes a polished end-user product:

- **Silent-uninstall execution** — running each program's own
  `UninstallString` with the right silent flags varies per installer
  (MSI vs InnoSetup vs NSIS etc.); the CLI prints the command rather than
  auto-executing it, since blindly running arbitrary uninstall strings
  unattended is itself a risk worth deciding on deliberately.
- **GUI** — this ships as a CLI; a WPF/WinUI front end can be layered on
  top of `DeepPurge.Core` without changing any engine logic.

## Author

**Francois Nel** — Sole Developer & Architect
South Africa
